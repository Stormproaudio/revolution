#<-- функции
API="$(grep_prop ro.build.version.sdk)";
ABI="$(grep_prop ro.product.cpu.abi)";
NAME="$(grep_prop ro.product.system.name)";

set_perm() {
	chown $1:$2 $4
	chmod $3 $4
	case $4 in
		*/vendor/etc/*)
			chcon 'u:object_r:vendor_configs_file:s0' $4
		;;
		*/vendor/*)
			chcon 'u:object_r:vendor_file:s0' $4
		;;
		*/data/adb/*.d/*)
			chcon 'u:object_r:adb_data_file:s0' $4
		;;
		*)
			chcon 'u:object_r:system_file:s0' $4
		;;
	esac
}

cp_perm() {
  if [ -f "$4" ]; then
    rm -f $5
    cat $4 > $5
    set_perm $1 $2 $3 $5
  fi
}

set_perm_recursive() {
	find $5 -type d | while read dir; do
		set_perm $1 $2 $3 $dir
	done
	find $5 -type f -o -type l | while read file; do
		set_perm $1 $2 $4 $file
	done
}

ddc_func() {
if [[ -f /data/adb/modules_update/viperfxmod/system/etc/permissions/privapp-permissions-com.pittvandewitt.viperfx.xml ]]; then
ui_print "Install ddc for viperfx..."
	mkdir /data/media/0/Android/data/com.pittvandewitt.viperfx
	set_perm 0 0 0770 /data/media/0/Android/data/com.pittvandewitt.viperfx
	mkdir /data/media/0/Android/data/com.pittvandewitt.viperfx/files
	set_perm 0 0 0770 /data/media/0/Android/data/com.pittvandewitt.viperfx/files
	cp -r /data/adb/modules_update/viperfxmod/system/DDC /data/media/0/Android/data/com.pittvandewitt.viperfx/files
	mv -f /data/adb/modules_update/viperfxmod/system/lib/libstdc++.so /data/adb/modules_update/viperfxmod/system/vendor/lib/libstdc++.so
	rm -r /data/adb/modules_update/viperfxmod/system/DDC
	rm -r /data/adb/modules_update/viperfxmod/system/lib
fi
}

allow_in_power_save_le25() {
ui_print "Adding the allow-in-power-save line to the white list..."
cp -r  $sys_tem/etc/sysconfig /data/adb/modules_update/viperfxmod/system/etc
set_perm_recursive 0 0 0755 0644 /data/adb/modules_update/viperfxmod/system/etc/sysconfig
exist_viper_allow=0
for F in /data/adb/modules_update/viperfxmod/system/etc/sysconfig/*.xml; do
[[ -f "$F" && -n "$(grep -e "com.audlabs.viperfx" "$F" 2>/dev/null)" ]] && exist_viper_allow=0
done
viper_allow_done=0
if [ "$exist_viper_allow" = 0 ]; then
for F in /data/adb/modules_update/viperfxmod/system/etc/sysconfig/*.xml; do
if [[ "$viper_allow_done" = 0 && -f "$F" && -n "$(grep -e "allow-in-power-save" "$F" 2>/dev/null)" ]]; then
num_str="$(sed -n '/\<allow-in-power-save/=' "$F" 2>/dev/null |head -n1)"
[ -n "$num_str" ] && sed -i "${num_str}s|.*|    <allow-in-power-save package=\"com.audlabs.viperfx\"/>\n\0|" "$F"
viper_allow_done=0
fi
done
fi
}

hidden_api_le25() {
ui_print "Adding the hidden-api-whitelisted-app line to the white list..."
exist_viper_allow=0
for F in /data/adb/modules_update/viperfxmod/system/etc/sysconfig/*.xml; do
[[ -f "$F" && -n "$(grep -e "com.audlabs.viperfx" "$F" 2>/dev/null)" ]] && exist_viper_allow=0
done
viper_allow_done=0
if [ "$exist_viper_allow" = 0 ]; then
for F in /data/adb/modules_update/viperfxmod/system/etc/sysconfig/*.xml; do
if [[ "$viper_allow_done" = 0 && -f "$F" && -n "$(grep -e "hidden-api-whitelisted-app" "$F" 2>/dev/null)" ]]; then
num_str="$(sed -n '/\<hidden-api-whitelisted-app/=' "$F" 2>/dev/null |head -n1)"
[ -n "$num_str" ] && sed -i "${num_str}s|.*|  <hidden-api-whitelisted-app package=\"com.audlabs.viperfx\" />\n\0|" "$F"
viper_allow_done=0
fi
done
fi
}

allow_in_power_save_ge26() {
ui_print "Adding the allow-in-power-save line to the white list..."
cp -r  $sys_tem/etc/sysconfig /data/adb/modules_update/viperfxmod/system/etc
set_perm_recursive 0 0 0755 0644 /data/adb/modules_update/viperfxmod/system/etc/sysconfig
exist_viper_allow=0
for F in /data/adb/modules_update/viperfxmod/system/etc/sysconfig/*.xml; do
[[ -f "$F" && -n "$(grep -e "com.pittvandewitt.viperfx" "$F" 2>/dev/null)" ]] && exist_viper_allow=0
done
viper_allow_done=0
if [ "$exist_viper_allow" = 0 ]; then
for F in /data/adb/modules_update/viperfxmod/system/etc/sysconfig/*.xml; do
if [[ "$viper_allow_done" = 0 && -f "$F" && -n "$(grep -e "allow-in-power-save" "$F" 2>/dev/null)" ]]; then
num_str="$(sed -n '/\<allow-in-power-save/=' "$F" 2>/dev/null |head -n1)"
[ -n "$num_str" ] && sed -i "${num_str}s|.*|    <allow-in-power-save package=\"com.pittvandewitt.viperfx\"/>\n\0|" "$F"
viper_allow_done=0
fi
done
fi
}

hidden_api_ge26() {
ui_print "Adding the hidden-api-whitelisted-app line to the white list..."
exist_viper_allow=0
for F in /data/adb/modules_update/viperfxmod/system/etc/sysconfig/*.xml; do
[[ -f "$F" && -n "$(grep -e "com.pittvandewitt.viperfx" "$F" 2>/dev/null)" ]] && exist_viper_allow=0
done
viper_allow_done=0
if [ "$exist_viper_allow" = 0 ]; then
for F in /data/adb/modules_update/viperfxmod/system/etc/sysconfig/*.xml; do
if [[ "$viper_allow_done" = 0 && -f "$F" && -n "$(grep -e "hidden-api-whitelisted-app" "$F" 2>/dev/null)" ]]; then
num_str="$(sed -n '/\<hidden-api-whitelisted-app/=' "$F" 2>/dev/null |head -n1)"
[ -n "$num_str" ] && sed -i "${num_str}s|.*|  <hidden-api-whitelisted-app package=\"com.pittvandewitt.viperfx\" />\n\0|" "$F"
viper_allow_done=0
fi
done
fi
}

path_audio() {
if [ -f /$sys_tem/etc/audio_effects.conf ]; then
ui_print "Patching audio_effects.conf in system..."
	cp_perm 0 0 0644 $sys_tem/etc/audio_effects.conf /data/adb/modules_update/viperfxmod/system/etc/audio_effects.conf
	SYSTEM_CONFIG_MAGISK=/data/adb/modules_update/viperfxmod/system/etc/audio_effects.conf
	sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/vendor\/lib\/soundfx\/libv4a_fx_jb.so\n  }/" $SYSTEM_CONFIG_MAGISK
	sed -i "s/^effects {/effects {\n  v4a_standard_fx {\n    library v4a_fx\n    uuid 41d3c987-e6cf-11e3-a88a-11aba5d5c51b\n  }/" $SYSTEM_CONFIG_MAGISK
fi
if [ -f /$sys_tem/vendor/etc/audio_effects.conf ]; then
ui_print "Patching audio_effects.conf in vendor..."
	cp_perm 0 0 0644 $sys_tem/vendor/etc/audio_effects.conf /data/adb/modules_update/viperfxmod/system/vendor/etc/audio_effects.conf
	VENDOR_CONFIG_MAGISK=/data/adb/modules_update/viperfxmod/system/vendor/etc/audio_effects.conf
	sed -i "s/^libraries {/libraries {\n  v4a_fx {\n    path \/vendor\/lib\/soundfx\/libv4a_fx_jb.so\n  }/" $VENDOR_CONFIG_MAGISK
	sed -i "s/^effects {/effects {\n  v4a_standard_fx {\n    library v4a_fx\n    uuid 41d3c987-e6cf-11e3-a88a-11aba5d5c51b\n  }/" $VENDOR_CONFIG_MAGISK
fi
if [ -f /$sys_tem/vendor/etc/audio_effects.xml ]; then
ui_print "Patching audio_effects.xml in vendor..."
	cp_perm 0 0 0644 $sys_tem/vendor/etc/audio_effects.xml /data/adb/modules_update/viperfxmod/system/vendor/etc/audio_effects.xml
	VENDOR_MAGISK_XML=/data/adb/modules_update/viperfxmod/system/vendor/etc/audio_effects.xml
	sed -i '/<libraries>/p;/<effects>/p;/<preprocess>/p;/<libraries>/,/<\/libraries>/d;/<effects>/,/<\/effects>/d;/<preprocess>/,/<\/preprocess>/d' $VENDOR_MAGISK_XML
	sed -i 's/<libraries>/<libraries>\n    <\/libraries>/g;s/<effects>/<effects>\n    <\/effects>/g;s/<preprocess>/<preprocess>\n    <\/preprocess>/g' $VENDOR_MAGISK_XML
	sed -i '/<libraries>/ a\        <library name="v4a_fx" path="libv4a_fx_jb.so"\/>' $VENDOR_MAGISK_XML
	sed -i '/<effects>/ a\        <effect name="v4a_standard_fx" library="v4a_fx" uuid="41d3c987-e6cf-11e3-a88a-11aba5d5c51b"\/>' $VENDOR_MAGISK_XML
fi
if [ -f /$sys_tem/vendor/etc/media_codecs_google_audio.xml ]; then
ui_print "Patching media_codecs_google_audio.xml in vendor..."
	cp_perm 0 0 0644 $sys_tem/vendor/etc/media_codecs_google_audio.xml /data/adb/modules_update/viperfxmod/system/vendor/etc/media_codecs_google_audio.xml
	MEDIA_MAGISK_XML=/data/adb/modules_update/viperfxmod/system/vendor/etc/media_codecs_google_audio.xml
	sed -i 's/\" >/\">/g;/aac.encoder/,/c>/s/\">/\">\n            <Limit name=\"complexity\" range=\"0-8\"  default=\"8\"\/>/g;/aac.encoder/,/c>/s/\">/\">\n            <Feature name=\"bitrate-modes\" value=\"CQ\"\/>/g;/flac.encoder/,/<\/MediaCodec>/s/default.*/default=\"8\"\/>/g;/flac.encoder/,/<\/MediaCodec>/s/value.*/value=\"CQ\"\/>/g' $MEDIA_MAGISK_XML	
fi
if [ -f /$sys_tem/vendor/etc/audio_effects_sec.xml ]; then
ui_print "Patching audio_effects_sec.xml in vendor..."
	cp_perm 0 0 0644 $sys_tem/vendor/etc/audio_effects_sec.xml /data/adb/modules_update/viperfxmod/system/vendor/etc/audio_effects_sec.xml
	SAMS_MAGISK_XML=/data/adb/modules_update/viperfxmod/system/vendor/etc/audio_effects_sec.xml
	sed -i '/<libraries>/p;/<effects>/p;/<preprocess>/p;/<libraries>/,/<\/libraries>/d;/<effects>/,/<\/effects>/d;/<preprocess>/,/<\/preprocess>/d' $SAMS_MAGISK_XML
	sed -i 's/<libraries>/<libraries>\n    <\/libraries>/g;s/<effects>/<effects>\n    <\/effects>/g;s/<preprocess>/<preprocess>\n    <\/preprocess>/g' $SAMS_MAGISK_XML
	sed -i '/<libraries>/ a\        <library name="v4a_fx" path="libv4a_fx_jb.so"\/>' $SAMS_MAGISK_XML
	sed -i '/<effects>/ a\        <effect name="v4a_standard_fx" library="v4a_fx" uuid="41d3c987-e6cf-11e3-a88a-11aba5d5c51b"\/>' $SAMS_MAGISK_XML
fi
for path in $sys_tem/vendor/lib/soundfx/*.so; do
	touch /data/adb/modules_update/viperfxmod/system/vendor/lib/soundfx/$(basename $path)
done
for path in $sys_tem/vendor/lib64/soundfx/*.so; do
	touch /data/adb/modules_update/viperfxmod/system/vendor/lib64/soundfx/$(basename $path)
done
}
#<-- функции

# Copy files for magisk -ge 19
if [ -d /data/adb/modules_update ]; then
ui_print "Copying files for magisk -ge 19..."
	touch /data/adb/modules_update/viperfxmod/auto_mount
	set_perm 0 0 0644 /data/adb/modules_update/viperfxmod/auto_mount
	set_perm 0 0 0755 /data/adb/modules_update/viperfxmod/system/scripts/magiskpolicy.sh
	set_perm 0 0 0755 /data/adb/modules_update/viperfxmod/system/scripts/permissive.sh
	mv -f /data/adb/modules_update/viperfxmod/system/scripts/magiskpolicy.sh /data/adb/service.d/magiskpolicy.sh
	mv -f /data/adb/modules_update/viperfxmod/system/scripts/permissive.sh /data/adb/service.d/permissive.sh
	mv -f /data/adb/modules_update/viperfxmod/system/scripts/sepolicy.rule /data/adb/modules_update/viperfxmod/sepolicy.rule
	mv -f /data/adb/modules_update/viperfxmod/system/scripts/post-fs-data.sh /data/adb/modules_update/viperfxmod/post-fs-data.sh
	rm -r /data/adb/modules_update/viperfxmod/system/scripts
	if [ $API -le 25 ]; then
	ui_print "Install for api -le 25..."
		path_audio
		allow_in_power_save_le25
		hidden_api_le25
		mv -f /data/adb/modules_update/viperfxmod/system/priv-app/ViPER/module.prop /data/adb/modules_update/viperfxmod/module.prop
		rm -f /data/adb/modules_update/viperfxmod/system/etc/permissions/privapp-permissions-com.pittvandewitt.viperfx.xml
		rm -r /data/adb/modules_update/viperfxmod/system/x86
		rm -r /data/adb/modules_update/viperfxmod/system/priv-app/ViPER4Android
	elif [ $API -eq 26 ]; then
	ui_print "Install for api -eq 26..."
		path_audio
		ddc_func
		allow_in_power_save_ge26
		hidden_api_ge26
		rm -f /data/adb/modules_update/viperfxmod/system/etc/permissions/privapp-permissions-com.audlabs.viperfx.xml
		rm -r /data/adb/modules_update/viperfxmod/system/x86
		rm -r /data/adb/modules_update/viperfxmod/system/priv-app/ViPER
	elif [ $API -eq 27 ]; then
	ui_print "Install for api -eq 27..."
		path_audio
		ddc_func
		allow_in_power_save_ge26
		hidden_api_ge26
		rm -f /data/adb/modules_update/viperfxmod/system/etc/permissions/privapp-permissions-com.audlabs.viperfx.xml
		rm -r /data/adb/modules_update/viperfxmod/system/x86
		rm -r /data/adb/modules_update/viperfxmod/system/priv-app/ViPER
	elif [ $API -eq 28 ]; then
	ui_print "Install for api -eq 28..."
		path_audio
		ddc_func
		allow_in_power_save_ge26
		hidden_api_ge26
		rm -f /data/adb/modules_update/viperfxmod/system/etc/permissions/privapp-permissions-com.audlabs.viperfx.xml
		rm -r /data/adb/modules_update/viperfxmod/system/x86
		rm -r /data/adb/modules_update/viperfxmod/system/priv-app/ViPER
	elif [ $API -ge 29 ]; then
	ui_print "Install for api -ge 29..."
		path_audio
		ddc_func
		allow_in_power_save_ge26
		hidden_api_ge26
		rm -f /data/adb/modules_update/viperfxmod/system/etc/permissions/privapp-permissions-com.audlabs.viperfx.xml
		rm -r /data/adb/modules_update/viperfxmod/system/x86
		rm -r /data/adb/modules_update/viperfxmod/system/priv-app/ViPER
	elif [[ $ABI = x86 && $API -le 25 ]]; then
	ui_print "Install for abi -eq x86..."
		rm -f /data/adb/modules_update/viperfxmod/system/lib/soundfx/libv4a_fx_jb.so
		mv -f /data/adb/modules_update/viperfxmod/system/x86/libv4a_fx_jb.so /data/adb/modules_update/viperfxmod/system/lib/soundfx/libv4a_fx_jb.so
		rm -r /data/adb/modules_update/viperfxmod/system/priv-app/ViPER/lib/arm
		mkdir /data/adb/modules_update/viperfxmod/system/priv-app/ViPER/lib/x86
		set_perm 0 0 0755 /data/adb/modules_update/viperfxmod/system/priv-app/ViPER/lib/x86
		mv -f /data/adb/modules_update/viperfxmod/system/x86/libV4AJniUtils.so /data/adb/modules_update/viperfxmod/system/priv-app/ViPER/lib/x86/libV4AJniUtils.so
		rm -r /data/adb/modules_update/viperfxmod/system/x86
	elif [[ $ABI = x86 && $API -ge 26 ]]; then
	ui_print "Install for abi -eq x86..."
		rm -f /data/adb/modules_update/viperfxmod/system/lib/soundfx/libv4a_fx_jb.so
		mv -f /data/adb/modules_update/viperfxmod/system/x86/libv4a_fx_jb.so /data/adb/modules_update/viperfxmod/system/lib/soundfx/libv4a_fx_jb.so
		rm -r /data/adb/modules_update/viperfxmod/system/priv-app/ViPER4Android/lib/arm
		mkdir /data/adb/modules_update/viperfxmod/system/priv-app/ViPER4Android/lib/x86
		set_perm 0 0 0755 /data/adb/modules_update/viperfxmod/system/priv-app/ViPER4Android/lib/x86
		mv -f /data/adb/modules_update/viperfxmod/system/x86/libV4AJniUtils.so /data/adb/modules_update/viperfxmod/system/priv-app/ViPER4Android/lib/x86/libV4AJniUtils.so
		rm -r /data/adb/modules_update/viperfxmod/system/x86
	fi
fi
